# Rawson Properties Agent Tracker - Cloud Deployment

🚀 Deploy to Render.com (FREE) - See DEPLOYMENT-GUIDE-RENDER.md for full instructions

## Quick Deploy
1. Sign up: https://render.com
2. Upload to GitHub
3. Connect to Render
4. Deploy!

## Default Login
- Admin: admin / rawson2024
- Change immediately after first login!

## For 10-20 agents, works perfectly on free tier!
